package com.acis.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acis.automation.library.PageBase;
import com.acis.automation.utilities.AcisException;

/**
 * /** This class is for defining objects of Login page and defining methods on
 * those objects.
 * 
 * @author Suraiya.Mulani
 * @since 15 Feb 2018
 *
 */

public class UserLoginPage extends PageBase {

	final static Logger logger = LoggerFactory.getLogger(UserLoginPage.class);

	public UserLoginPage() throws AcisException {
	}

	@FindBy(xpath = "//*[@id='txtUsername']")

	WebElement TextBoxUserName;

	@FindBy(id = "txtPassword")

	WebElement TextBoxPassword;

	@FindBy(xpath = "//*[contains(@id,'btnLogin')]")

	WebElement ButtonLogin;

	@FindBy(xpath = "//*[text()='Logout']")
	WebElement ButtonLogout;

	By TextBoxUserNameLocator = By.xpath("//*[@id='txtUsername']");

	/**
	 * Reusable method is used login to application for all other test scripts
	 * 
	 * @param strUserName
	 * @param strPassword
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 * 
	 */
	public void loginUserToApplication(String strUserName, String strPassword) throws AcisException {
		waitForPageLoad();
		enterUserName(strUserName);
		enterPassword(strPassword);
		clickLoginBtn();

	}

	/**
	 * 
	 * @param strUserName
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */

	public void enterUserName(String strUserName) throws AcisException {
		waitForElement(TextBoxUserName);
		enterText(TextBoxUserName, strUserName);
		logger.info("Entered UserName as: " + strUserName);
		testLoggerInfo("Entered UserName as: " + strUserName);
	}

	/**
	 * 
	 * @param strPassword
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */
	public void enterPassword(String strPassword) throws AcisException {
		enterText(TextBoxPassword, strPassword);
		logger.info("Entered Password ");

		testLoggerInfo("Entered Password ");

	}

	/**
	 * This method is used to click on Login button
	 * 
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */

	public void clickLoginBtn() throws AcisException {
		clickWebElement(ButtonLogin);
		logger.info("Clicked on Login button");

		testLoggerInfo("Clicked on Login button");

	}

	/**
	 * This method is used to check whether User name check box is preset or not
	 * 
	 * @return
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */
	public boolean isUserNameTextBoxPresent() throws AcisException {
		if (isElementPresent(TextBoxUserNameLocator)) {
			logger.info("UserName TextBox is Present");

			testLoggerInfo("UserName TextBox is Present");

			return true;
		} else {
			logger.info("UserName TextBox is not Present");

			testLoggerInfo("UserName TextBox is not Present");
			return false;
		}
	}

}