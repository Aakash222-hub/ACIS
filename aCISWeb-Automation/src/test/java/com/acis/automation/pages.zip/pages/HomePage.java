package com.acis.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.acis.automation.library.PageBase;
import com.acis.automation.utilities.AcisException;

/**
 * This class is for defining objects of Home page and defining methods on those
 * objects.
 * 
 * @author Suraiya.Mulani
 * @since 15 Feb 2018
 *
 */
public class HomePage extends PageBase {

	final static Logger logger = LoggerFactory.getLogger(HomePage.class);

	public HomePage() throws AcisException {
	}

	@FindBy(xpath = "//*[@id='ImgLogoPath']")
	WebElement ImageHomePageLogo;

	@FindBy(xpath = "//*[@id='SwitchRoleMenuPanel']/ul/li/a/span")
	WebElement TextMasterSuperAdmin;

	@FindBy(xpath = "//*[text()='Help']")
	WebElement LinkHelp;

	@FindBy(xpath = "//*[@id='lblActiveCourses']/a")
	WebElement LinkActiveCourses;

	@FindBy(xpath = "//input[@name='radNumberOfRecords2']")
	WebElement TextBoxDisplay;

	@FindBy(xpath = "(//*[text()='Organizations'])[1]")
	WebElement LinkHomePageOrganization;

	@FindBy(xpath = "(//*[text()='Organizations'])[2]")
	WebElement LinkOrganization;

	@FindBy(xpath = "//*[@id='contnetframe']")
	WebElement FrameContent;

	@FindBy(xpath = "//*[contains(text(),'Logout')]")
	WebElement linkLogout;

	@FindBy(xpath = "//*[text()='Dashboard']")
	WebElement linkDashboard;

	@FindBy(xpath = "//*[@class='rmToggle']/..")
	WebElement iconSwitchUser;

	@FindBy(xpath = "//*[text()='Master Super Admin']")
	WebElement linkMasterSuperAdmin;

	@FindBy(xpath = "(//*[@id='SwitchRoleMenuPanel']//following::span[1])[1]")
	WebElement textSwitchUser;

	@FindBy(xpath = "//*[text()='Training Manager']")
	WebElement linkTrainingManager;

	public static By linkTrainingManagerLocator = By.xpath("//*[text()='Training Manager']");

	@FindBy(xpath = "//*[text()='Primary Org Admin']")
	WebElement linkPrimaryOrgAdmin;

	public static By dashBoardLocator = By.xpath("//*[text()='Dashboard']");
	public static By menuHome = By.xpath("//*[text()='Home']");
	public static By linkLogoutLocator = By.xpath("//*[contains(text(),'Logout')]");
	public String strRoleName = "//*[text()='ABC']";

	/**
	 * This method is used to verify Home page
	 * 
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */
	public void verfiyHomePage() throws AcisException {

		try {
			String name = TextMasterSuperAdmin.getText().trim();
			Assert.assertEquals(name, "Master Super Admin", "Failed to verify Home Page ");

			testLoggerPass("verified home page successfully");
			logger.info("verified home page successfully");

		} catch (Exception e) {

			testLoggerFail("Failed to verify home page");
			getStackTrace(e, "Failed to verify home page");

		}
	}

	/**
	 * This method is used to click on help link on Master Super Admin/Org Admin
	 * console
	 * 
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */

	public void clickOnHelpLinkAndNavigateToNewWindow() throws Exception, AcisException {
		waitForElement(LinkHelp);
		clickWebElement(LinkHelp);
		logger.info("Clicked on 'Help' link");

		testLoggerInfo("Clicked on 'Help' link");

		switchToWindow();
		maximizeWindow();
		scrollDownTillPageEnd();

	}

	/**
	 * This method is used to click on Active users link on Dashboard
	 * 
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */

	public void clickOnActiveCourses() throws Exception, AcisException {
		switchToFrameByIndex(0);
		waitForElement(LinkActiveCourses);
		clickWebElement(LinkActiveCourses);

		testLoggerInfo("Clicked on Active Courses link");

		logger.info("Clicked on Active Courses link");

	}

	/**
	 * This method is used to click on Logout link
	 * 
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */
	public void clickLogout() throws AcisException {
		closeWindowsExceptParent();
		waitForPageLoad();
		switchToDefaultContent();
		waitForElement(linkLogout);
		clickWebElement(linkLogout);
		logger.info("Clicked on Logout");

		testLoggerInfo("Clicked on Logout");

	}

	/**
	 * This method is used to verify user successfully logged into Application
	 * 
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */
	public void verifyLogin() throws AcisException {

		waitForPageLoad();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			getStackTrace(e, "Failed to wait till page get loaded");
		}
		switchToDefaultContent();
		Assert.assertTrue(verifyLoggedInUser(), "Failed to Login");
	}

	/**
	 * This method is used to verify user successfully logged into Application
	 * 
	 * @return
	 * @throws AcisException
	 * @author (Original) Unknown
	 * @author (Modified) Chandrashekhar.Reddy
	 * @since (Modified) 17 July 2019
	 */

	public boolean verifyLoggedInUser() throws AcisException {
		waitForPageLoad();
		if (isElementPresent(dashBoardLocator)) {
			logger.info("Homepage is verified successfully");

			testLoggerPass("Homepage is verified successfully");

			return true;
		} else if (isElementPresent(menuHome)) {
			logger.info("Homepage is verified successfully");

			testLoggerPass("Homepage is verified successfully");

			return true;
		} else
			return false;
	}

	/**
	 * This method is used to hover on Switch User icon
	 * 
	 * @throws AcisException
	 * @author shahenshaha.mulani
	 * @since 07 August 2019
	 */

	public HomePage hoverOnSwitchUserIcon() throws AcisException {
		waitForPageLoad();
		switchToDefaultContent();
		waitForElement(iconSwitchUser);
		hoverOverElement(iconSwitchUser);
		logger.info("Mouse hovered on Switch user icon");

		testLoggerInfo("Mouse hovered on Switch user icon");

		return this;
	}

	/**
	 * This method is used to click on Master Super Admin link
	 * 
	 * @throws AcisException
	 * @author shahenshaha.mulani
	 * @since 07 August 2019
	 */

	public HomePage clickOnMasterSuperAdminLink() throws AcisException {

		waitForElementClickable(linkMasterSuperAdmin);
		clickWebElement(linkMasterSuperAdmin);
		logger.info("Clicked on MSA link");

		testLoggerInfo("Clicked on MSA link");

		waitForPageLoad();
		return this;
	}

	/**
	 * This method is used to verify User is on ILMS Home page
	 * 
	 * @author Shahenshaha.Mulani
	 * @throws AcisException
	 * @since 22 July 2019
	 */

	public HomePage verifyUserIsOnILMSHomePage() throws AcisException {
		waitAndVerifyElement(dashBoardLocator);
		logger.info("Verified that User is on ILMS Home page");
		testLoggerPass("Verified that User is on ILMS Home page");
		return this;
	}

	/**
	 * This method is used to verify Logout link is not present under User's setting
	 * 
	 * @author Shahenshaha.Mulani
	 * @throws AcisException
	 * @since 22 July 2019
	 */

	public HomePage verifyLogoutLinkIsNotPresentOnILMS() throws AcisException {

		Assert.assertFalse(isElementPresent(linkLogoutLocator), "Logout link is present on ILMS Home page");
		logger.info("Verified that Logout link is not present on ILMS Home page");
		testLoggerPass("Verified that Logout link is not present on ILMS Home page");
		return this;
	}

	/**
	 * This method is used to verify User is on LC Home page
	 * 
	 * @author Shahenshaha.Mulani
	 * @throws AcisException
	 * @since 23 July 2019
	 */

	public HomePage verifyUserIsOnLCHomePage() throws AcisException {
		waitAndVerifyElement(menuHome);
		logger.info("Verified that User is on LC Home page");
		testLoggerPass("Verified that User is on LC Home page");
		return this;
	}

	/**
	 * This method is used to verify User is on given console
	 * 
	 * @author Shahenshaha.Mulani
	 * @throws AcisException
	 * @since 07 August 2019
	 */

	public HomePage verifyUserIsOnGivenConsole(String strConsole) throws AcisException {
		waitForPageLoad();
		waitForElement(textSwitchUser);
		Assert.assertEquals(textSwitchUser.getText().trim(), strConsole, "Failed to verify user is on given console");
		logger.info("Verified that User is on '" + strConsole + " ' console");
		testLoggerPass("Verified that User is on '" + strConsole + " ' console");
		return this;
	}

	/**
	 * This method is used to click on Training Manager link
	 * 
	 * @throws AcisException
	 * @author shahenshaha.mulani
	 * @since 08 August 2019
	 */

	public HomePage clickOnTrainingManagerLink() throws AcisException {

		waitForElementClickable(linkTrainingManager);
		clickWebElement(linkTrainingManager);
		logger.info("Clicked on Training Manager link");

		testLoggerInfo("Clicked on Training Manager link");

		waitForPageLoad();
		return this;
	}

	/**
	 * This method is used to click on Primary Org Admin link
	 * 
	 * @throws AcisException
	 * @author shahenshaha.mulani
	 * @since 08 August 2019
	 */

	public HomePage clickOnPrimaryOrgAdminLink() throws AcisException {

		waitForElementClickable(linkPrimaryOrgAdmin);
		clickWebElement(linkPrimaryOrgAdmin);
		logger.info("Clicked on Primary Org Admin link");

		testLoggerInfo("Clicked on Primary Org Admin link");

		waitForPageLoad();
		return this;
	}

	/**
	 * This method is used to click on roles drop down menu
	 * 
	 * @throws AcisException
	 * @author Nivedita Yeolekar
	 * @since 08 August 2019
	 */

	public HomePage clickOnRoleNameFromRolesDropDownMenu(String rolenameLC) {
		waitForPageLoad();
		getDynamicWebElement(strRoleName, rolenameLC).click();
		testLoggerInfo("Clicked on '" + rolenameLC + " Role");
		logger.info("Clicked on '" + rolenameLC + " Role");
		return this;
	}

	/**
	 * This method is used to verify training manager link is present in dropdown
	 * 
	 * @throws AcisException
	 * @author Nivedita.Yeolekar
	 * @since 15 August 2019
	 */

	public HomePage verifyTrainingManagerLinkInDropDown() throws AcisException {
		waitForElementClickable(linkTrainingManager);
		Assert.assertTrue(isElementPresent(linkTrainingManagerLocator),
				"Dropdown does not display training manager role along with other roles");
		logger.info("Dropdown displays training manager role along with other roles");
		testLoggerInfo("Dropdown displays training manager role along with other roles");
		waitForPageLoad();
		return this;
	}

}
